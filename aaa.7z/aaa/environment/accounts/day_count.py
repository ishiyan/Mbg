from enum import Enum
from typing import Union, Any
from numbers import Real
from datetime import date, datetime, timedelta

#d30act, https://github.com/hcnn/d30act
# Synonyms: 30/Actual
# ISO 20022 -- A003

#act365l, https://github.com/hcnn/act365l
# Synonyms: Actual/365L, Actual/Actual Basic Rule, ISMA-Year
# ISO 20022 -- A009

#act_icma, https://github.com/hcnn/act_icma
# Synonyms: Act/Act ICMA, Actual/Actual ICMA, ISMA-99, Act/Act ISMA
# ISO 20022 -- A006

class DayCount(Enum): # Convention
    RAW = 0
    """
    'raw'
    """

    THIRTY_360_U = 1 # d30360u
    """
    '30/360 isda', 30_360 isda'
    '30/360 us', 30_360 us'
    '30u/360', 30u_360'
    """

    THIRTY_365 = 2 # d30365
    """
    '30/365', 30_365'
    """

    ACTUAL_360 = 4 # act360
    """
    'actual/360', 'actual_360', 'actual360',
    'act/360', 'act_360', 'act360'
    """

    ACTUAL_365_FIXED = 5 # act365f
    """
    'actual/365 fixed', 'actual_365 fixed', 'actual365 fixed',
    'act/365 fixed', 'act_365 fixed', 'act365 fixed'
    """

    ACTUAL_365_ISDA = 8 # act_isda
    """
    'actual/actual isda', 'actual_actual isda',
    'act/act isda', 'act_act isda',
    'actual/365 isda', 'actual_365 isda',
    'act/365 isda', 'act_365 isda'
    """

    ACTUAL_365_AFB = 10 # act_afb
    """
    'actual/actual afb', 'actual_actual afb',
    """

    THIRTY_360_S = 11 # d30360s
    """
    '30/360 eurobond basis', 30_360 eurobond basis'
    '30/360 icma', 30_360 icma'
    '30s/360', 30s_360'
    """

    THIRTY_360_E2 = 12 # d30360e2
    """
    '30/360 e2', 30_360 e2'
    '30e2/360', 30e2_360'
    """

    THIRTY_360_E3 = 13 # d30360e2
    """
    '30/360 e3', 30_360 e3'
    '30e3/360', 30e3_360'
    """

    ACTUAL_365_NONLEAP = 14 # act365n
    """
    'actual/365 nonleap', 'actual_365 nonleap'
    """

    THIRTY_360_M = 21 # d30360m
    """
    '30/360 us eom', 30_360 us eom'
    """

    THIRTY_360_N = 22 # d30360n
    """
    '30/360 nasd', 30_360 nasd'
    """

    THIRTY_360_P = 23 # d30360p
    """
    '30e+/360', 30e+_360'
    """

def is_leap_year(y: int) -> bool:
    return not(y % 4) and (bool(y % 100) or not(y % 400))

def date_to_jd(year: int, month: int, day: int) -> int:
    a = int((14 - month) / 12.)
    y = int(year + 4800 - a)
    m = int(month + (12 * a) - 3)

    jd = day + int(((153 * m) + 2) / 5.0) + (y * 365)
    jd += int(y / 4.) - int(y / 100.) + int(y / 400.) - 32045
    return jd

def jd_to_date(jd: int) -> tuple[int, int, int]:
    a = jd + 32044
    b = int(((4 * a) + 3) / 146097.)
    c = a - int((b * 146097) / 4.)

    d = int(((4 * c) + 3) / 1461.)
    e = c - int((d * 1461) / 4.)
    m = int(((5 * e) + 2) / 153.)
    m2 = int(m / 10)

    day = e + 1 - int(((153 * m) + 2) / 5.)
    month = (m + 3 - (12 * m2))
    year = ((b * 100) + d - 4800 + m2)

    return year, month, day

def _common_360_entry(y1: int, m1: int, y2: int, m2: int) -> int:
    diff_days = (360 * (y2 - y1))
    diff_days += (30 * (m2 - m1))
    return diff_days

def _common_throw_negative_diff_days(diff_days: int):
    if diff_days < 0:
        raise ValueError(
            f'Newer date y2-m2-d2 is older than previous date y1-m1-d1.')

def _common_360_exit(diff_days: int, denom: float) -> float:
    if diff_days < 0:
        raise ValueError(
            f'Newer date y2-m2-d2 is older than previous date y1-m1-d1.')
    elif diff_days == 0:
        return 0.0
    else:
        return diff_days / denom

def d30360e(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int,
            maturity: bool) -> float:
    """
    Source:
        https://github.com/hcnn/d30360e
    Synonyms:
        - 30E/360 ISDA
        - Eurobond Basis ISDA-2000
        - German SWX
        - German Master EBF MA
    
    ISO 20022:
        A007
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month and
    a 360-day year.
    
    Accrued interest to a value date on the last day of a month shall
    be the same as to the 30th calendar day of the same month.
    
    This means that a 31st is assumed to be a 30th and the 28 Feb (or
    29 Feb for a leap year) is assumed to be equivalent to a 30 Feb.
    
    However, if the last day of the maturity coupon period is the last
    day of February, it will not be assumed to be a 30th. It is a
    variation of the 30/360 (ICMA) method commonly used for eurobonds.
    
    The usage of this variation is only relevant when the coupon periods
    are scheduled to end on the last day of the month.
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    if (m2 == 2) and (d2 >= 28):
        diff_days += d2 if maturity else 30
    else:
        diff_days += 30 if d2 > 30 else d2

    if (m1 == 2) and (d1 >= 28):
        diff_days -= 30
    else:
        diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360u(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360u
    Synonyms:
        - 30/360 ISDA
        - 30U/360
        - 30/360 US
        - 30/360 Bond Basis
        - 30/360 U.S. Municipal
        - American Basic Rule
    
    ISO 20022:
        A001
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month
    and a 360-day year.
    
    Accrued interest to a value date on the last day of a month shall
    be the same as to the 30th calendar day of the same month, except
    for February, and provided that the interest period started on a
    30th or a 31st.
    
    This means that a 31st is assumed to be a 30th if the period started
    on a 30th or a 31st and the 28 Feb (or 29 Feb for a leap year) is
    assumed to be a 28th (or 29th).
    
    It is the most commonly used 30/360 method for US straight and
    convertible bonds.
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    if (d2 == 31) and (d1 >= 30):
        diff_days += 30
    else:
        diff_days += d2

    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360n(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360n
    Synonyms:
        - 30/360 NASD
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    if d2 == 31:
        diff_days += 32 if d1 < 30 else 30        
    else:
        diff_days += d2

    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360p(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360p
    Synonyms:
        - 30E+/360
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    diff_days += 32 if d2 == 31 else d2        
    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360s(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360s
    Synonyms:
        - 30/360 ICMA
        - 30/360 Eurobond Basis
        - ISDA-2006
        - 30S/360 Special German
    
    ISO 20022:
        A011
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month
    and a 360-day year.
    
    Accrued interest to a value date on the last day of a month
    shall be the same as to the 30th calendar day of the same month,
    except for February.
    
    This means that a 31st is assumed to be a 30th and the 28 Feb
    (or 29 Feb for a leap year) is assumed to be a 28th (or 29th).
    
    It is the most commonly used 30/360 method for non-US straight
    and convertible bonds issued before 01/01/1999.
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    diff_days += 30 if d2 > 30 else d2        
    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360m(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360m
    Synonyms:
        - 30/360 US EOM
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    rule2 = (m1 == 2) and (d1 >= 28)
    rule3 = rule2 and (m2 == 2) and (d2 >= 28)
    rule4 = (d2 == 31) and (d1 >= 30)
    
    if rule2:
        diff_days -= 30
    else:
        diff_days -= 30 if d1 > 30 else d1    
    if rule4 or rule3:
        diff_days += 30
    else:
        diff_days += d2

    return _common_360_exit(diff_days, 360.0)

def d30360e3(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360e3
    Synonyms:
        - 30E3/360
        - Eurobond basis model 3
    
    ISO 20022:
        A013
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month
    and a 360-day year.
    
    Accrued interest to a value date on the last day of a month
    shall be the same as to the 30th calendar day of the same month.
    
    This means that a 31st is assumed to be a 30th and the 28 Feb
    (or 29 Feb for a leap year) is assumed to be equivalent to a
    30 Feb.
    
    It is a variation of the 30E/360 (or Eurobond basis) method
    where the last day of February is always assumed to be a 30th,
    even if it is the last day of the maturity coupon period.
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    if (m2 == 2) and (d2 >= 28):
        diff_days += 30
    else:
        diff_days += 30 if d2 > 30 else d2
    
    if (m1 == 2) and (d1 >= 28):
        diff_days -= 30
    else:
        diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30360e2(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30360e2
    Synonyms:
        - 30E2/360
        - Eurobond basis model 2
    
    ISO 20022:
        A012
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month and
    a 360-day year.
    
    Accrued interest to a value date on the last day of a month shall
    be the same as to the 30th calendar day of the same month, except
    for the last day of February whose day of the month value shall
    be adapted to the value of the first day of the interest period
    if the latter is higher and if the period is one of a regular
    schedule.
    
    This means that a 31st is assumed to be a 30th and the 28th Feb
    of a non-leap year is assumed to be equivalent to a 29th Feb
    when the first day of the interest period is a 29th, or to a 30th
    Feb when the first day of the interest period is a 30th or a 31st.
    
    The 29th Feb of a leap year is assumed to be equivalent to a 30th
    Feb when the first day of the interest period is a 30th or a 31st.

    Similarly, if the coupon period starts on the last day of February,
    it is assumed to produce only one day of interest in February as if
    it was starting on a 30th Feb when the end of the period is a 30th
    or a 31st, or two days of interest in February when the end of the
    period is a 29th, or 3 days of interest in February when it is the
    28th Feb of a non-leap year and the end of the period is before the
    29th.
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    leap1 = is_leap_year(y1)
    if leap1 and (m2 == 2) and (d2 == 28):
        diff_days += 29 if d1 == 29 else (30 if d1 >= 30 else d2)
    elif leap1 and (m2 == 2) and (d2 == 29):
        diff_days += 30 if d1 >= 30 else d2
    else:
        diff_days += 30 if d2 > 30 else d2
    
    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def d30365(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/d30365
    Synonyms:
        - 30/365
    
    ISO 20022:
        A002
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on a 30-day month
    in a way similar to the 30/360 (basic rule) and a 365-day year.

    Accrued interest to a value date on the last day of a month shall
    be the same as to the 30th calendar day of the same month, except
    for February.
    
    This means that a 31st is assumed to be a 30th and the 28 Feb (or
    29 Feb for a leap year) is assumed to be a 28th (or 29th).
    """
    diff_days = _common_360_entry(y1, m1, y2, m2)

    if d2 == 31 and d1 >= 30:
        diff_days += 30
    else:
        diff_days += d2

    diff_days -= 30 if d1 > 30 else d1

    return _common_360_exit(diff_days, 360.0)

def act365n(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int, matu: bool) -> float:
    """
    Source:
        https://github.com/hcnn/act365n
    Synonyms:
        - Actual/365NL
        - Actual/365 Non-Leap
    
    ISO 20022:
        A014
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on the actual
    number of accrued days in the interest period, excluding
    any leap day from the count, and a 365-day year.
    """
    diff_days = date_to_jd(y2, m2, d2)
    diff_days -= date_to_jd(y1, m1, d1)
    _common_throw_negative_diff_days(diff_days)
    if diff_days == 0:
        return 0.0

    leap_years = 0
    if is_leap_year(y1) and (m1 <= 2):
        leap_years += 1
    if (y1 != y2) and is_leap_year(y2) and (m2 >= 3):
        leap_years += 1        
    if (y1+1) < y2:
        now = y1 + 1
        while now < y2:
            if is_leap_year(now):
                leap_years += 1
            now += 1        
    diff_days -= leap_years        
    if diff_days <= 0:
        return 0.0
    return diff_days / 365.0

def act365f(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/act365f
    Synonyms:
        - Actual/365 Fixed
        - Act/365 Fixed
        - A/365 Fixed
        - A/365F
        - English
    
    ISO 20022:
        A005
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on the actual
    number of accrued days in the interest period and a 365-day year.
    """
    diff_days = date_to_jd(y2, m2, d2)
    diff_days -= date_to_jd(y1, m1, d1)

    return _common_360_exit(diff_days, 365.)

def act360(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/act360
    Synonyms:
        - Actual/360
        - Act/360
        - A/360
        - French
    
    ISO 20022:
        A004
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on the actual
    number of accrued days in the interest period and a 360-day year.
    """
    diff_days = date_to_jd(y2, m2, d2)
    diff_days -= date_to_jd(y1, m1, d1)

    return _common_360_exit(diff_days, 360.)

def act_isda(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/act_isda
    Synonyms:
        - Actual/Actual ISDA
        - Act/Act ISDA
        - Actual/365 ISDA
        - Act/365 ISDA
    
    ISO 20022:
        A008
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on the actual number
    of accrued days of the interest period that fall on a normal year,
    divided by 365, added to the actual number of days of the interest
    period that fall on a leap year, divided by 366.
    """
    if y1 == y2:
        denom = 366. if is_leap_year(y2) else 365.
        diff_days = date_to_jd(y2, m2, d2)
        diff_days -= date_to_jd(y1, m1, d1)
        return _common_360_exit(diff_days, denom)
    elif y1 < y2:
        denom_a = 366. if is_leap_year(y1) else 365.
        diff_a = date_to_jd(y1, 12, 31)
        diff_a -= date_to_jd(y1, m1, d1)

        denom_b = 366. if is_leap_year(y2) else 365.
        diff_b = date_to_jd(y2, m2, d2)
        diff_b -= date_to_jd(y2, 1, 1)

        diff_y = y2 - y1 - 1
        return (diff_a / denom_a) + (diff_b / denom_b) + diff_y
    else:
        raise Exception(
            'Newer date y2-m2-d2 is older than previous date y1-m1-d1.')

def act_afb(y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
    """
    Source:
        https://github.com/hcnn/act_afb
    Synonyms:
        - Actual/Actual AFB
        - Actual/Actual FBF
    
    ISO 20022:
        A010
        https://www.iso20022.org/15022/uhb/mt565-16-field-22f.htm

    Method whereby interest is calculated based on the actual
    number of accrued days and a 366-day year (if 29 Feb falls
    in the coupon period) or a 365-day year (if 29 Feb does not
    fall in the coupon period).
    
    If a coupon period is longer than one year, it is split by
    repetitively separating full year sub-periods counting backwards
    from the end of the coupon period (a year backwards from a 28 Feb
    being 29 Feb, if it exists).
    
    The first of the sub-periods starts on the start date of the
    accrued interest period and thus is possibly shorter than a year.
    
    Then the interest computation is operated separately on each
    sub-period and the intermediate results are summed up.
    """
    if y1 == y2:
        denom = 366. if (m1 < 3 and is_leap_year(y1)) else 365.
        diff_days = date_to_jd(y2, m2, d2)
        diff_days -= date_to_jd(y1, m1, d1)
        return _common_360_exit(diff_days, denom)
    elif y1 < y2:
        denom_a = 366. if (m1 < 3 and is_leap_year(y1)) else 365.
        diff_a = date_to_jd(y1, 12, 31)
        diff_a -= date_to_jd(y1, m1, d1)

        denom_b = 366. if (m2 >= 3 and is_leap_year(y2)) else 365.
        diff_b = date_to_jd(y2, m2, d2)
        diff_b -= date_to_jd(y2, 1, 1)

        diff_y = y2 - y1 - 1
        return (diff_a / denom_a) + (diff_b / denom_b) + diff_y
    else:
        raise Exception(
            'Newer date y2-m2-d2 is older than previous date y1-m1-d1.')

def year_frac(method: DayCount,
            y1: int, m1: int, d1: int,
            y2: int, m2: int, d2: int) -> float:
        if method == DayCount.ACTUAL_365_AFB:
            return act_afb( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.ACTUAL_365_ISDA:
            return act_isda(y1, m1, d1, y2, m2, d2)
        elif method == DayCount.ACTUAL_365_FIXED:
            return act365f( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.ACTUAL_360:
            return act360(  y1, m1, d1, y2, m2, d2)
        elif method == DayCount.ACTUAL_365_NONLEAP:
            return act365n( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_E2:
            return d30360e2(y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_E3:
            return d30360e3(y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_M:
            return d30360m( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_N:
            return d30360n( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_P:
            return d30360p( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_360_S:
            return d30360s( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_365_U:
            return d30360u( y1, m1, d1, y2, m2, d2)
        elif method == DayCount.THIRTY_365:
            return d30365(  y1, m1, d1, y2, m2, d2)
        else:
            raise ValueError('Invalid day count convention.')
