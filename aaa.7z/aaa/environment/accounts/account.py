from typing import Callable, Union, Any
from numbers import Real
import datetime as dt

from .execution_side import ExecutionSide
from .day_count_convention import DayCountConvention
from .performance import Performance
from .position import Position

class Account(object):
    def __init__(self,
                 initial_balance: Real = 10000,
                 risk_free_rate: Real = 0.0,
                 convention: DayCountConvention = DayCountConvention.RAW):
        """
        Args:
            initial_balance real:
                Initial balance.
                Default: 10000
            risk_free_rate Real:
                Risk-free rate. In context of Sortino ratio,
                it is the Minimum Acceptable Return (MAR, used
                in Sortino's early work), or Desired Target Return
                (DTR, used in Sortino's later works).
                Default: 0.0
            convention:
                Day count convention.
                Default: DayCountConvention.RAW
        """
        self.initial_balance = initial_balance

        self.position = Position()
        self.performance = Performance(initial_balance=initial_balance,
            risk_free_rate=risk_free_rate, convention=convention)
        self.subscribers = {}
        self.cash = initial_balance
        self.balance = initial_balance
        self.max_balance = initial_balance
        self.min_balance = initial_balance
        self.max_drawdown = 0
        self.is_halted = False
        
    def reset(self):
        self.position.reset()
        self.performance.reset()
        self.subscribers.clear()
        self.cash = self.initial_balance
        self.balance = self.initial_balance
        self.max_balance = self.initial_balance
        self.min_balance = self.initial_balance
        self.max_drawdown = 0
        self.is_halted = False
        
    def subscribe(self, who: Any, callback: Callable[..., Any]):
        self.subscribers[who] = callback
        
    def unsubscribe(self, who: Any):
        del self.subscribers[who]
        
    def on_update(self, *args, **kwargs):
        for who, callback in self.subscribers.items():
            callback(*args, **kwargs)

    @property
    def has_no_position(self) -> bool:
        return self.position.quantity_signed == 0

    @property
    def has_position(self) -> bool:
        return self.position.quantity_signed != 0

    def update_performance(self,
            price_high: Real,
            price_low: Real,
            price_last: Real,
            datetime: dt.datetime):
        self.position.update_performance(price_high, price_low)

        balance = self.cash + self.position.value(price_high)
        if self.max_balance < balance:
            self.max_balance = balance

        balance = self.cash + self.position.value(price_low)
        if self.min_balance > balance:
            self.min_balance = balance
            drawdown = (self.max_balance - self.min_balance)    
            if self.max_drawdown < drawdown:
                self.max_drawdown = drawdown

        self.balance = self.cash + self.position.value(price_last)
                
    def close_position(self,
                       datetime: Union[Real, dt.datetime, dt.date, Any],
                       price: Real,
                       commission: Real = 0,
                       notes: str = None):
        rts, cash_flow = self.position.close(datetime = datetime, \
            price = price, commission = commission, notes = notes)
        self.cash += cash_flow
        self.update_balance(price)
        self.performance.add(rts)

    def execute(self,
               datetime: Union[Real, dt.datetime, dt.date, Any],
               operation: str,
               quantity: Real,
               price: Real,
               commission: Real = 0,
               notes: str = None):
        assert isinstance(operation, str) and (operation in 'BS'), \
            ValueError('Account:update: Invalid operation')
        assert isinstance(quantity, Real) and (quantity > 0), \
            ValueError(f'Invalid quantity {quantity}')
        assert isinstance(price, Real), \
            ValueError(f'Invalid price {price}')
        assert isinstance(commission, Real), \
            ValueError(f'Invalid commission {commission}')

        side = ExecutionSide.BUY if (operation == 'B') else ExecutionSide.SELL
        rts, cash_flow = self.position.execute(datetime = datetime, side = side, \
            quantity = quantity, price = price, commission = commission, notes = notes)
        
        self.cash += cash_flow
        self.update_balance(price)
        self.performance.add(rts)
        return self.balance

    def __repr__(self):
        return f'{self.__class__.__name__}(initial_balance={self.initial_balance})'
    
    def __str__(self):
        return (
            f'{self.__class__.__name__}{{'
            f'cash={self.cash}, '
            f'balance={str(self.positibalanceon_datetime)}, '
            f'max_balance={self.max_balance}, '
            f'min_balance={self.min_balance}, '
            f'max_drawdown={self.max_drawdown}}}')
