from enum import Enum
from typing import Union, Any
from numbers import Real
from datetime import date, datetime, timedelta

# https://github.com/AnatolyBuga/yearfrac/blob/main/tests/integration_test.rs
# https://github.com/AnatolyBuga/yearfrac/blob/main/src/lib.rs

# Day count conventions are used to calculate interest accrual between coupon payment dates.
# Intraday refers to the calculation of interest within a single day.
# Since intraday interest accrual is not a standard practice in debt securities,
# there is no specific day count convention for intraday.

# https://support.microsoft.com/en-us/office/yearfrac-function-3844141e-c76d-4143-82b6-208454ddc6a8
# Excel YEARFRAC function:
# Basis Optional: The type of day count basis to use.
# 0: US (NASD) 30/360
# 1: Actual/actual
# 2: Actual/360
# 3: Actual/365
# 4: European 30/360

# https://en.wikipedia.org/wiki/Day_count_convention
#
# 30/360 methods
# {\displaystyle \mathrm {DayCountFactor} ={\frac {360\times (Y_{2}-Y_{1})+30\times (M_{2}-M_{1})+(D_{2}-D_{1})}{360}}}
# frac_year = (360*(y2-y1) + 30*(m2-m1) + (d2-d1)) / 360
#
# "30/360 Bond Basis", "30A/360"
# ISDA 2006 Section 4.16(f)
# "ISDA Definitions, Section 4.16" (PDF). 2006. Archived from the original (PDF) on 2014-09-13. Retrieved 2014-09-18.
# https://web.archive.org/web/20140913145444/http://www.hsbcnet.com/gbm/attachments/standalone/2006-isda-definitions.pdf
# This convention is exactly as 30U/360 below, except for the first two rules.
# Note that the order of calculations is important:
# {\displaystyle D_{1}=\min(D_{1},30)}.
# If {\displaystyle D_{1}>29} then {\displaystyle D_{2}=\min(D_{2},30)}
# d1=min(d1,30)
# if (d1 > 29) then d2=min(d2,30)
#
# "30/360 US", "30U/360", "30/360", "US (NASD) 30/360"
# Date adjustment rules (more than one may take effect;
# apply them in order, and if a date is changed in one rule
# the changed value is used in the following rules):
# If the investment is EOM and (Date1 is the last day of February)
# and (Date2 is the last day of February), then change D2 to 30.
# If the investment is EOM and (Date1 is the last day of February),
# then change D1 to 30.
# If D2 is 31 and D1 is 30 or 31, then change D2 to 30.
# If D1 is 31, then change D1 to 30.
#
# "30E/360", "Eurobond basis (ISDA 2006)", "30/360 ICMA", "30/360 ISMA", "30S/360", "Special German"
# Date adjustment rules:
# If D1 is 31, then change D1 to 30.
# If D2 is 31, then change D2 to 30.
#
# "30E/360 ISDA", "Eurobond basis (ISDA 2000)", "German"
# Date adjustment rules:
# If D1 is the last day of the month, then change D1 to 30.
# If D2 is the last day of the month (unless Date2 is the maturity date and M2 is February), then change D2 to 30.
#
# "Actual/Actual ICMA", "Actual/Actual", "Act/Act ICMA", "ISMA-99", "Act/Act ISMA"
# {\displaystyle \mathrm {DayCountFactor} ={\frac {\mathrm {Days} (\mathrm {Date1} ,\mathrm {Date2} )}{\mathrm {Freq} \times \mathrm {Days} (\mathrm {Date1} ,\mathrm {Date3} )}}}
# 

class DayCountConvention(Enum):
    RAW = 'raw'
    ACTUAL_365 = 'actual/365' # 'actual/365', 'actual_365', 'actual365'
    ACTUAL_360 = 'actual/360' # 'actual/360', 'actual_360', 'actual360'
    THIRTY_360 = '30/360' # '30/360', '30_360'

SECONDS_IN_GREGORIAN_YEAR = 31556952

def duration(date1: Union[Real, datetime, date, Any],
             date2: Union[Real, datetime, date, Any],
             convention: DayCountConvention) -> float:
    if (date1 is None) or (date2 is None):
        return 0
    delta = date1 - date2

    if convention == DayCountConvention.ACTUAL_365:
        if isinstance(delta, timedelta):
            return abs(delta.days / 365)
        if isinstance(delta, Real):
            return abs(delta / (365 * 60 * 60 * 24))

    elif convention == DayCountConvention.ACTUAL_360:
        if isinstance(delta, timedelta):
            return abs(delta.days / 360)
        if isinstance(delta, Real):
            return abs(delta / (360 * 60 * 60 * 24))

    elif convention == DayCountConvention.THIRTY_360:
        assert hasattr(date1, 'year') and hasattr(date1, 'month') and hasattr(date1, 'day')
        assert hasattr(date2, 'year') and hasattr(date2, 'month') and hasattr(date2, 'day')
        df = (min(date2.day, 30) + max(0, (30 - date1.day))) / 360
        mf = (date2.month - date1.month - 1) / 12
        yf = (date2.year - date1.year)
        return abs(df + mf + yf)

    #else: # RAW
    if isinstance(delta, Real):
        pass
    elif isinstance(delta, timedelta):
        delta = delta.total_seconds()
    else:
        raise ValueError(f'Invalid date1 {date1} or date2 {date2} or convention {convention}')
    return abs(delta) / SECONDS_IN_GREGORIAN_YEAR
