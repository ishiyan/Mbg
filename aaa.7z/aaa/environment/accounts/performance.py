from typing import List, Sequence, Union, Any
from numbers import Real
import datetime as dt
import numpy as np

from roundtrips.performance import Roundtrip, RoundtripPerformance
from .performance_record import PerformanceRecord
from .day_count_convention import DayCountConvention, duration

# https://www.pm-research.com/content/iijinvest/3/3/59
# Sortino, F.A.; Price, L.N. (1994). "Performance measurement in a downside risk framework". Journal of Investing. 3 (3): 50–8. doi:10.3905/joi.3.3.59
#
# "Sortino: A 'Sharper' Ratio" (PDF). Red Rock Capital. Retrieved February 16, 2014.
# http://www.redrockcapital.com/Sortino__A__Sharper__Ratio_Red_Rock_Capital.pdf
#
# https://en.wikipedia.org/wiki/Rate_of_return
# According to the CFA Institute's Global Investment Performance Standards (GIPS),[3]
#"Returns for periods of less than one year must not be annualized."
# https://www.cfainstitute.org/en/membership/professional-development/refresher-readings/gips-overview
# Overview of the Global Investment Performance Standards "GIPS Standards"
#
# https://github.com/Peter-Staadecker/Lions-and-Tigers-and-Sortinos-Oh-My/blob/main/tiingo%20analysis%20multi-yr%20monthly%20v4%20%20-%20API%20key%20blank.py
# min_acceptable_return_in_period
# ------------------ calculate Sortino ratio =  (stock return - minimum acceptable return)/ downside std dev
# note 1. returns are % growth, not growth ratio
# note 2. downside std dev counts all periods both above and below target in the std dev denominator,
#   i.e. the zero values in the downside are not thrown away. For emphasis on this point see
#   e.g. http://www.redrockcapital.com/Sortino__A__Sharper__Ratio_Red_Rock_Capital.pdf
# note 3. I use a geometric average for average growth in calculating the numerator of the Sortino ratio.
#   Some may prefer an arithmetic ratio. Based on some quick tests the difference is likely minor.
# note 4. I use std. deviation for the population, not for a sample. Again the differences are likely minor.
# note 5. There are however, major differences in ratios depending on whether the data frequency is daily, weekly
#   monthly or yearly. As a result, it seems that the ratios (up/down market capture and Sortino) are more
#   useful for comparison between stocks when measured with the same data frequency, rather than as an absolute measure.
#   The beta ratio seems least influenced by frequency.
#
# downsideStdDevAnnlzd: float = downsideStdDevPeriod * (PeriodsInYr ** 0.5)  # <----////////adjust if needed
#
#if dataFreqStr == "weekly":
#    PeriodsInYr = 52
#elif dataFreqStr == "monthly":
#    PeriodsInYr = 12
#elif dataFreqStr == "annually":
#    PeriodsInYr = 1
#elif dataFreqStr == "daily":
#    PeriodsInYr = 253  # using an average
#
# https://github.com/kunnn1/Quant-Calc/blob/main/quant_calc.py
# def calculate_sharpe_ratio(returns, risk_free_rate, trading_days=252):
#   excess_returns = returns - risk_free_rate / trading_days
#    sharpe_ratio = np.sqrt(trading_days) * excess_returns.mean() / excess_returns.std()
#    return sharpe_ratio
# def calculate_sortino_ratio(returns, risk_free_rate, trading_days=252):
#    downside_returns = returns[returns < 0]
#    excess_returns = returns - risk_free_rate / trading_days
#    sortino_ratio = np.sqrt(trading_days) * excess_returns.mean() / downside_returns.std()
#    return sortino_ratio
# def calculate_max_drawdown(returns):
#    cumulative_returns = (1 + returns).cumprod()
#    peak = cumulative_returns.cummax()
#    drawdown = (cumulative_returns - peak) / peak
#    max_drawdown = drawdown.min()
#    return max_drawdown
#
#


class Performance(object):
    def __init__(self,
                 initial_balance: Real = 100000,
                 risk_free_rate: Real = 0.0,
                 convention: DayCountConvention = DayCountConvention.RAW):
        """
        Args:
            initial_balance real:
                Initial balance.
                Default: 10000
            risk_free_rate Real:
                Risk-free rate. In context of Sortino ratio,
                it is the Minimum Acceptable Return (MAR, used
                in Sortino's early work), or Desired Target Return
                (DTR, used in Sortino's later works).
                Default: 0.0
            convention:
                Day count convention.
                Default: DayCountConvention.RAW
        """
        self.initial_balance = initial_balance
        self.risk_free_rate = risk_free_rate
        self.convention = convention
        
        self.roundtrips = RoundtripPerformance(
            initial_balance=initial_balance,
            risk_free_rate=risk_free_rate,
            convention=convention)
        self.last_balance: float = initial_balance
        self.max_balance: float = initial_balance
        self.max_drawdown: float = 0
        self.max_drawdown_ratio: float = 0
        self.time: List[dt.datetime] = []
        self.balance: List[float] = []
        self.returns: List[float] = []
        self.returns_annual: List[float] = []
        self.sortino_downside_returns: List[float] = []
        self.sortino_downside_returns_annual: List[float] = []
        self._returns_mean: float = 0
        self._returns_std: float = 0
        self._returns_tdd: float = 0
        self._returns_annual_mean: float = 0
        self._returns_annual_std: float = 0
        self._returns_annual_tdd: float = 0

        self.first_time = None
        self.last_time = None
        self._total_duration_annualized: float = 0

        self.max_net_profit = 0
        self.max_drawdown = 0
        self.max_drawdown_percent = 0
        self.returns_on_investments = []
        self.sortino_downside_returns = []
        self.returns_on_investments_annual = []
        self.sortino_downside_returns_annual = []
    
    def reset(self):
        self.roundtrips.reset()
        self.last_balance = self.initial_balance
        self.max_balance = self.initial_balance
        self.max_drawdown = 0
        self.max_drawdown_ratio = 0
        self.time.clear()
        self.balance.clear()
        self.returns.clear()
        self.returns_annual.clear()
        self.sortino_downside_returns.clear()
        self.sortino_downside_returns_annual.clear()
        self._returns_mean = 0
        self._returns_std = 0
        self._returns_tdd = 0
        self._returns_annual_mean = 0
        self._returns_annual_std = 0
        self._returns_annual_tdd = 0

        self.first_time = None
        self.last_time = None
        self._total_duration_annualized = 0

        self.net_profit = 0
        self.max_net_profit = 0
        self.max_drawdown = 0
        self.max_drawdown_percent = 0
        self.returns_on_investments.clear()
        self.sortino_downside_returns.clear()
        self.returns_on_investments_annual.clear()
        self.sortino_downside_returns_annual.clear()
        self.sharpe_count=0
    
    def add(self, rts: List[Roundtrip]):
        for rt in rts:
            self.roundtrips.add(rt)
    
    def update(self, balance: float, time: dt.datetime):
        frac_years = 0
        if self.last_time is not None:
            frac_years = duration(time, self.last_time, self.convention)

        changed = False
        if (self.first_time is None) or (self.first_time > time):
            self.first_time = time
            changed = True
        if (self.last_time is None) or (self.last_time < time):
            self.last_time = time
            changed = True
        if changed:
            d = duration(self.last_time, self.first_time, self.convention)
            self._total_duration_annualized = d

        self.time.append(time)
        self.balance.append(balance)
        ret = balance / self.last_balance - 1
        self.returns.append(ret)
        self.last_balance = balance
        self._returns_mean = np.mean(self.returns)
        self._returns_std = np.std(self.returns, ddof=1)
        downside = ret - self.risk_free_rate
        if downside < 0:
            self.sortino_downside_returns.append(downside)
            self._returns_tdd = np.sqrt(np.mean(np.power(
                self.sortino_downside_returns, 2)))
        ret_ann = ret / frac_years if frac_years != 0 else 0
        self.returns_annual.append(ret_ann)
        self._returns_annual_mean = np.mean(self.returns_annual)
        self._returns_annual_std = np.std(self.returns_annual, ddof=1)
        downside = ret_ann - self.risk_free_rate
        if downside < 0:
            self.sortino_downside_returns_annual.append(downside)
            self._returns_annual_tdd = np.sqrt(np.mean(np.power(
                self.sortino_downside_returns_annual, 2)))

        if self.max_balance < balance:
            self.max_balance = balance
        delta = self.max_balance - balance
        if self.max_drawdown < delta:
            self.max_drawdown = delta
            self.max_drawdown_ratio = self.max_drawdown / self.max_balance
    
    @property
    def sharpe_ratio(self):
        """Sharpe ratio over balance returns"""
        if (self._returns_mean is None) or \
            (self._returns_std is None) or (self._returns_std == 0):
            return None
        return self._returns_mean / self._returns_std

    @property
    def sharpe_ratio_annual(self):
        """Sharpe ratio over annualized balance returns"""
        if (self._returns_annual_mean is None) or \
            (self._returns_annual_std is None) or (self._returns_annual_std == 0):
            return None
        return self._returns_annual_mean / self._returns_annual_std
    
    @property
    def sortino_ratio(self):
        """Sortino ratio over balance returns"""
        if (self._returns_mean is None) or \
            (self._returns_tdd is None) or (self._returns_tdd == 0):
            return None
        return (self._returns_mean - self.risk_free_rate) / self._returns_tdd

    @property
    def sortino_ratio_annual(self):
        """Sortino ratio over annualized balance returns"""
        if (self._returns_annual_mean is None) or \
            (self._returns_annual_tdd is None) or (self._returns_annual_tdd == 0):
            return None
        return (self._returns_annual_mean - self.risk_free_rate) / self._returns_annual_tdd
        
    @property
    def calmar_ratio(self):
        """Calmar ratio over balance returns"""
        if (self._returns_mean is None) or (self.max_drawdown_ratio == 0):
            return None
        return self._returns_mean / self.max_drawdown_ratio

    @property
    def calmar_ratio_annual(self):
        """Calmar ratio over annualized balance returns"""
        if (self._returns_annual_mean is None) or (self.max_drawdown_ratio == 0):
            return None
        return self._returns_annual_mean / self.max_drawdown_ratio
    
    @property
    def rate_of_return(self):
        """Rate of return"""
        if self.initial_balance == 0:
            return None
        return self.last_balance / self.initial_balance
    
    @property
    def rate_of_return_annual(self):
        """Annualized rate of return"""
        if (self._total_duration_annualized == 0) or (self.initial_balance == 0):
            return None
        return (self.last_balance / self.initial_balance) / self._total_duration_annualized
    
    @property
    def recovery_factor(self):
        rorann = self.rate_of_return_annual
        if rorann is None or self.max_drawdown_ratio == 0:
            return None
        return rorann / self.max_drawdown_ratio
    
    def __repr(self):
        return (
            f'{self.__class__.__name__}('
            f'initial_balance={self.initial_balance}, '
            f'risk_free_rate={self.risk_free_rate}, '
            f'convention={self.convention})'
        )
    
    def __str__(self):
        return '\n'.join([f'{str(k)}: {str(v)}' for (k, v) in self.__dict__.items()])

"""
https://github.com/melvinmt/sharpefolio/blob/2.x/develop/sharpefolio/calc.py
	def sortino(self):
		'''
		sortino is an adjusted ratio which only takes the 
		standard deviation of negative returns into account
		'''
		adj_ret = [a - b for a, b in zip(self.ret, self.b_ret)]
		avg_ret = np.mean(adj_ret)

		# Take all negative returns.
		neg_ret = [a ** 2 for a in adj_ret if a < 0]
		# Sum it.
		neg_ret_sum = np.sum(neg_ret)
		# And calculate downside risk as second order lower partial moment.
		down_risk = np.sqrt(neg_ret_sum / self.n)

		if down_risk > 0.0001:
			sortino = avg_ret / down_risk
		else:
			sortino = 0

		return sortino

"""