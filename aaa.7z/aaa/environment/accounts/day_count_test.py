from datetime import datetime, timedelta
import unittest

from day_count import is_leap_year, jd_to_date, date_to_jd
from day_count import d30360e, d30360u, d30360n, d30360p, d30360s
from day_count import d30360m, d30360e2, d30360e3, d30365, act365n
from day_count import act365f, act360, act_isda, act_afb

class TestIsLeapYear(unittest.TestCase):
    def test_leap_years(self):
        lyrs = [
            1804, 1808, 1812, 1816, 1820, 1824, 1828, 1832, 1836, 1840, 1844,
            1848, 1852, 1856, 1860, 1864, 1868, 1872, 1876, 1880, 1884, 1888,
            1892, 1896, 1904, 1908, 1912, 1916, 1920, 1924, 1928, 1932, 1936,
            1940, 1944, 1948, 1952, 1956, 1960, 1964, 1968, 1972, 1976, 1980,
            1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016, 2020, 2024,
            2028, 2032, 2036, 2040, 2044, 2048, 2052, 2056, 2060, 2064, 2068,
            2072, 2076, 2080, 2084, 2088, 2092, 2096, 2104, 2108, 2112, 2116,
            2120, 2124, 2128, 2132, 2136, 2140, 2144, 2148, 2152, 2156, 2160,
            2164, 2168, 2172, 2176, 2180, 2184, 2188, 2192, 2196, 2204, 2208,
            2212, 2216, 2220, 2224, 2228, 2232, 2236, 2240, 2244, 2248, 2252,
            2256, 2260, 2264, 2268, 2272, 2276, 2280, 2284, 2288, 2292, 2296,
            2304, 2308, 2312, 2316, 2320, 2324, 2328, 2332, 2336, 2340, 2344,
            2348, 2352, 2356, 2360, 2364, 2368, 2372, 2376, 2380, 2384, 2388,
            2392, 2396, 2400]
        x = [is_leap_year(y) for y in lyrs]
        t = [True for _ in lyrs]
        self.assertListEqual(x, t, 'Leap years')

    def test_nonleap_years(self):
        yrs = [
            2017, 2018, 2019, 2021, 2022, 2023, 2025, 2026, 2027, 2029, 2030]
        x = [is_leap_year(y) for y in yrs]
        t = [False for _ in yrs]
        self.assertListEqual(x, t, 'Non-leap years')

class TestJulianDay(unittest.TestCase):
    def test_conversion(self):
        # 24-Nov (-4713) 12Uhr
        # 25-Nov (-4713) 12Uhr
        # 11-Feb-2014 12Uhr, 2456700
        # 27-Feb-6700 12Uhr, 4168242
        # 28-Feb-6700 12Uhr, 4168243
        # 01-Mar-6700 12Uhr, 4168244
        # 02-Mar-6700 12Uhr, 4168245
        jds = [
            0, 1, 2456700, 4168242, 4168243, 4168244, 4168245]
        years = [
            -4713, -4713, 2014, 6700, 6700, 6700, 6700]
        months = [
            11, 11, 2, 2, 2, 3, 3]
        days = [
            24, 25, 11, 27, 28, 1, 2]
        for jd, y, m, d in zip(jds, years, months, days):
            print(f'Date {y:04d}-{m:02d}-{d:02d} <-> JD {jd}\n')
            y_, m_, d_ = jd_to_date(jd)
            self.assertEqual(y_, y, f'Year: {y_} != {y}')
            self.assertEqual(m_, m, f'Month: {m_} != {m}')
            self.assertEqual(d_, d, f'Day: {d_} != {d}')
            jd_ = date_to_jd(y, m, d)
            self.assertEqual(jd_, jd, f'JD: {jd_} != {jd}')

class TestD30360e(unittest.TestCase):
    def test_mature(self):
        x = d30360e(2018, 12, 15, 2019, 3, 1, False)
        self.assertEqual(round(x, 8), 0.21111111)

    def test_not_mature(self):
        x = d30360e(2018, 12, 15, 2019, 3, 1, True)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360e2(unittest.TestCase):
    def test(self):
        x = d30360e2(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360e3(unittest.TestCase):
    def test(self):
        x = d30360e3(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360u(unittest.TestCase):
    def test(self):
        x = d30360u(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360n(unittest.TestCase):
    def test(self):
        x = d30360n(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360p(unittest.TestCase):
    def test(self):
        x = d30360p(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360s(unittest.TestCase):
    def test(self):
        x = d30360s(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30360m(unittest.TestCase):
    def test(self):
        x = d30360m(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestD30365(unittest.TestCase):
    def test(self):
        x = d30365(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.20821918)

class TestAct365n(unittest.TestCase):
    def test(self):
        x = act365n(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.20821918)

class TestAct365f(unittest.TestCase):
    def test(self):
        x = act365f(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.20821918)

class TestAct360(unittest.TestCase):
    def test(self):
        x = act360(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.21111111)

class TestActIsda(unittest.TestCase):
    def test(self):
        x = act_isda(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.20547945)
        #self.assertEqual(round(x, 8), round(0.208219178082118, 8))

        x = act_isda(2018, 12, 31, 2019, 1, 1)
        self.assertEqual(round(x, 8), round(1. / 365., 8))

        x = act_isda(1994, 6, 30, 1997, 6, 30)
        self.assertEqual(round(x, 8), 3.0)

        x = act_isda(1994, 2, 10, 1994, 6, 30)
        self.assertEqual(round(x, 8), round(140. / 365., 8))

class TestActAfb(unittest.TestCase):
    def test(self):
        x = act_afb(2018, 12, 15, 2019, 3, 1)
        self.assertEqual(round(x, 8), 0.20547945)
        #self.assertEqual(round(x, 8), 0.20821918)
        #self.assertEqual(round(x, 15), 0.208219178082192)

        x = act_afb(2018, 12, 31, 2019, 1, 1)
        self.assertEqual(round(x, 8), round(1. / 365., 8))

        x = act_afb(1994, 6, 30, 1997, 6, 30)
        self.assertEqual(round(x, 8), 3.0)

        x = act_afb(1994, 2, 10, 1994, 6, 30)
        self.assertEqual(round(x, 8), round(140. / 365., 8))

if __name__ == "__main__":
    unittest.main()
