package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
)

type outputCsv struct {
	rekeningnummer              string
	accountID                   string
	cppiPercentage              string
	country                     string
	valid                       string
	firstOccurence              string
	unchanged                   string
	administrationFee           string
	administrationFeePercentage string
	umbrellaFundTax             string
	umbrellaFundTaxPercentage   string
	btw                         string
	btwPercentage               string
	fundCost                    string
	fundCostPercentage          string
	umbrellaFundCost            string
	umbrellaFundCostPercentage  string
	promotion                   string
	promotionPercentage         string
}

// CalculatorResponse is automatically generated on https://mholt.github.io/json-to-go/ from the output of
// http://expostcostscalculator.a1-comfort.k8ssa.otas.nv/api/v1/ExPostCosts/Search?AccountId=961818&Year=2019
type CalculatorResponse struct {
	ServiceCosts []struct {
		Value      float64 `json:"value"`
		Percentage float64 `json:"percentage"`
		MlKeyName  string  `json:"mlKeyName"`
		Order      int     `json:"order"`
	} `json:"serviceCosts"`
	Promotion struct {
		Value      float64     `json:"value"`
		Percentage float64     `json:"percentage"`
		MlKeyName  interface{} `json:"mlKeyName"`
		Order      int         `json:"order"`
	} `json:"promotion"`
	TaxCosts []struct {
		Value      float64 `json:"value"`
		Percentage float64 `json:"percentage"`
		MlKeyName  string  `json:"mlKeyName"`
		Order      int     `json:"order"`
	} `json:"taxCosts"`
	FundsCosts []struct {
		Value      float64 `json:"value"`
		Percentage float64 `json:"percentage"`
		MlKeyName  string  `json:"mlKeyName"`
		Order      int     `json:"order"`
	} `json:"fundsCosts"`
	TotalCostsAmount     float64 `json:"totalCostsAmount"`
	TotalCostsPercentage float64 `json:"totalCostsPercentage"`
	RevenueOverview      struct {
		BrutoAmount  float64 `json:"brutoAmount"`
		BrutoPercent float64 `json:"brutoPercent"`
		NetAmount    float64 `json:"netAmount"`
		NetPercent   float64 `json:"netPercent"`
		CostAmount   float64 `json:"costAmount"`
		CostPercent  float64 `json:"costPercent"`
	} `json:"revenueOverview"`
	ExAntePredictions struct {
		Returns []struct {
			Year  int     `json:"year"`
			Gross float64 `json:"gross"`
			Net   float64 `json:"net"`
		} `json:"returns"`
	} `json:"exAntePredictions"`
}

func main() {
	file := writeOutputHeader()
	defer file.Close()

	rows := readInputCsv("input.csv")
	for _, row := range rows {
		cr, err := callCalculator(row.accountID)
		if err != nil {
			os.Stderr.WriteString("Rekeningnummer " + row.rekeningnummer + " " + err.Error() + "\n\n")
			continue
		}
		row.enrichWith(cr)
		row.writeOutputCsv(file)
	}
}

func writeOutputHeader() *os.File {
	file, err := os.Create("output.csv")
	if err != nil {
		panic("couldn't create output.csv")
	}
	io.WriteString(file, "Rekeningnummer;AccountId;CPPIPercentage;Country;Valid;FirstOccurence;Unchanged;AdministrationFee;AdministrationFeePercentage;UmbrellaFundTax;UmbrellaFundTaxPercentage;BTW;BTWPercentage;FundCost;FundCostPercentage;UmbrellaFundCost;UmbrellaFundCostPercentage;Promotion;PromotionPercentage\n")
	file.Sync()
	return file
}

func readInputCsv(filename string) []*outputCsv {
	f, err := os.Open(filename)
	if err != nil {
		panic("couldn't open " + filename)
	}
	defer f.Close()

	r := csv.NewReader(f)
	r.Comment = '#'
	r.Comma = ';'

	lines, err := r.ReadAll()
	if err != nil {
		panic("couldn't read " + filename + ": " + err.Error())
	}

	output := make([]*outputCsv, 0)
	for _, line := range lines {
		d := outputCsv{
			rekeningnummer:      line[0],
			accountID:           line[1],
			country:             line[2],
			cppiPercentage:      line[3],
			valid:               "",
			firstOccurence:      "",
			unchanged:           "",
			promotion:           "0",
			promotionPercentage: "0",
		}

		if d.country == "1" {
			d.country = "BinckBank Belgie"
		} else {
			d.country = "BinckBank"
		}

		output = append(output, &d)
	}

	return output
}

func callCalculator(accountID string) (CalculatorResponse, error) {
	url := "http://expostcostscalculator.a1-comfort.k8ssa.otas.nv/api/v1/ExPostCosts/Search?AccountId=" + accountID + "&Year=2019"

	var cr CalculatorResponse
	resp, err := http.Get(url)
	if err != nil {
		return cr, fmt.Errorf("couldn't call expostcostscalculator for accoint id %s: %w", accountID, err)
	}

	rawJSON, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return cr, fmt.Errorf("couldn't read response body for accoint id %s: %w", accountID, err)
	}

	err = json.Unmarshal(rawJSON, &cr)
	if err != nil {
		return cr, fmt.Errorf("couldn't decode response json for accoint id %s: %w: %s", accountID, err, string(rawJSON))
	}

	return cr, nil
}

func float2Str(val float64) string {
	return strconv.FormatFloat(val, 'f', -1, 64)
}

func (row *outputCsv) enrichWith(cr CalculatorResponse) {
	row.administrationFee = float2Str(cr.ServiceCosts[0].Value)
	row.administrationFeePercentage = float2Str(cr.ServiceCosts[0].Percentage)
	row.umbrellaFundTax = float2Str(cr.TaxCosts[0].Value)
	row.umbrellaFundTaxPercentage = float2Str(cr.TaxCosts[0].Percentage)
	row.btw = float2Str(cr.TaxCosts[1].Value)
	row.btwPercentage = float2Str(cr.TaxCosts[1].Percentage)
	row.fundCost = float2Str(cr.FundsCosts[0].Value)
	row.fundCostPercentage = float2Str(cr.FundsCosts[0].Percentage)
	row.umbrellaFundCost = float2Str(cr.FundsCosts[1].Value)
	row.umbrellaFundCostPercentage = float2Str(cr.FundsCosts[1].Percentage)
	row.promotion = float2Str(cr.Promotion.Value)
	row.promotionPercentage = float2Str(cr.Promotion.Percentage)
}

func (row *outputCsv) writeOutputCsv(file *os.File) {
	const comma = ";"
	s := row.rekeningnummer + comma + row.accountID + comma + row.cppiPercentage + comma + row.country + comma
	s += row.valid + comma + row.firstOccurence + comma + row.unchanged + comma
	s += row.administrationFee + comma + row.administrationFeePercentage + comma
	s += row.umbrellaFundTax + comma + row.umbrellaFundTaxPercentage + comma
	s += row.btw + comma + row.btwPercentage + comma
	s += row.fundCost + comma + row.fundCostPercentage + comma
	s += row.umbrellaFundCost + comma + row.umbrellaFundCostPercentage + comma
	s += row.promotion + comma + row.promotionPercentage + "\n"

	io.WriteString(file, s)
	file.Sync()
}
