# Ex-post Costs 2019

Connect to Topline Oracle `TOA01` as `lees:read` in PL/SQL.

## Binck Comfort

Copy `ExPostCostResults2018_v1.xlsx` to the `ExPostCostResults2019_v1.xlsx`.

You have to add four new sheets to the `ExPostCostResults2019_v1.xlsx` file with Ex-Post results for 2019.

### Sheet 1: ExPostCostsResults 2019

Execute the following query and save results to the `input.csv` file

```sql
select r.rekeningnummer as Rekeningnummer, t.acc_account_id as AccountId, t.cpc_cppi_configuration_id as Country, t.cppi_percentage as CPPIPercentage from BAM.BAM_ACCOUNT_CPPI_CONFIGS t
left join TOPLINE.TOP_REKENINGEN r on r.rekeningid = t.acc_account_id order by t.acc_account_id asc
```

There should be about 5272 records in the file.

For each account id we have to make a GET REST call to the `ExPostCostsCalculator` micro-service running on A1 Kubernetes cluster.

Given the account id 961218 and the year 2019, the URL to call is [http://expostcostscalculator.a1-comfort.k8ssa.otas.nv/api/v1/ExPostCosts/Search?AccountId=961218&Year=2019](http://expostcostscalculator.a1-comfort.k8ssa.otas.nv/api/v1/ExPostCosts/Search?AccountId=961218&Year=2019),

You will get the following JSON result back:

```json
{
    "serviceCosts": [
        {
            "value": 131.39,
            "percentage": 0.5,
            "mlKeyName": "AdministrationFee",
            "order": 1
        }
    ],
    "promotion": null,
    "taxCosts": [
        {
            "value": 2.1842689126491557,
            "percentage": 0.01,
            "mlKeyName": "UmbrellaFundTax",
            "order": 1
        },
        {
            "value": 27.59,
            "percentage": 0.1,
            "mlKeyName": "BTW",
            "order": 2
        }
    ],
    "fundsCosts": [
        {
            "value": 67.731702153965372,
            "percentage": 0.26,
            "mlKeyName": "FundCost",
            "order": 1
        },
        {
            "value": 123.57547593810449,
            "percentage": 0.47,
            "mlKeyName": "UmbrellaFundCost",
            "order": 2
        }
    ],
    "totalCostsAmount": 352.47144700471904,
    "totalCostsPercentage": 1.3399999999999999,
    "revenueOverview": {
        "brutoAmount": 2986.0314470047169,
        "brutoPercent": 0.0,
        "netAmount": 2633.5599999999977,
        "netPercent": 0.0,
        "costAmount": 352.47144700471904,
        "costPercent": 1.3399999999999999
    },
    "exAntePredictions": {
        "returns": [
            {
                "year": 1,
                "gross": 1247.9188191119647,
                "net": 916.80787749603041
            },
            {
                "year": 3,
                "gross": 4012.5524318315,
                "net": 2980.449429514756
            },
            {
                "year": 5,
                "gross": 7036.3530812113459,
                "net": 5090.3782029424219
            }
        ]
    }
}
```

These JSON fields should be put in the following columns into the CSV file:

| Excel column (csv header) | JSON field |
| ------------------------- | ---------- |
| Rekeningnummer | account number from the input CSV |
| AccountId | account id from the input CSV |
| CPPIPercentage | CPPI % from the input CSV |
| Country | `BinckBank België` if CPPI config from the input CSV is 1, `BinckBank` otherwise. |
| Valid | leave this empty |
| FirstOccurence | leave this empty |
| Unchanged | leave this empty |
| AdministrationFee | serviceCosts[0].value |
| AdministrationFeePercentage | serviceCosts[0].percentage |
| UmbrellaFundTax | taxCosts[0].value |
| UmbrellaFundTaxPercentage | taxCosts[0].percentage |
| BTW | taxCosts[1].value |
| BTWPercentage | taxCosts[1].percentage |
| FundCost | fundsCosts[0].value |
| FundCostPercentage | fundsCosts[0].percentage |
| UmbrellaFundCost | fundsCosts[1].value |
| UmbrellaFundCostPercentage | fundsCosts[1].percentage |
| Promotion | promotion.value |
| PromotionPercentage | promotion.percentage |


Create a new `ExPostCostsResults 2019` sheet and import the generated CSV file.

### Sheet 2: Latest CPPI % before 2019

Create a new `Latest CPPI % before 2019` sheet for latest CPPI % per account before 01-01-2018. Execute the following query and copy results to this sheet.

```sql
select f.acc_account_id,100 - f.cushion as CPPI_PERCENTAGE,f.status_investmentplan_datetime from BAM_ACCOUNT_CPPI_CONFIGS b
left join BAM.BAM_RISKINTAKES f on b.acc_account_id = f.acc_account_id
where f.status_investmentplan_datetime = (select max(t1.status_investmentplan_datetime) from BAM.BAM_RISKINTAKES t1 where f.acc_account_id = t1.acc_account_id
and trunc(t1.status_investmentplan_datetime) < to_date('2019-01-01','yyyy-MM-dd') and t1.status_investmentplan in  (2,3))
```

### Sheet 3: All CPPI % in 2019

Create a new `All CPPI % in 2019` sheet for all CPPI % changes in 2019. Execute the following query and copy results to this sheet.

```sql
select f.acc_account_id,f.status_investmentplan_datetime , 100 - f.cushion as CPPI_PERCENTAGE2019 from BAM_ACCOUNT_CPPI_CONFIGS b
left join BAM.BAM_RISKINTAKES f on b.acc_account_id = f.acc_account_id
where f.status_investmentplan in (2,3) and trunc(f.status_investmentplan_datetime) >= to_date('2019-01-01','yyyy-MM-dd') and trunc(f.status_investmentplan_datetime) < to_date('2020-01-01','yyyy-MM-dd')
```

### Sheet 4: All acc. unchanged CPPI 2019

Create a new `All acc. unchanged CPPI 2019` sheet for all unchanged CPPI % of < 2019 compared with all CPPI % from 2019. Execute the following query and copy results to this sheet.

```sql
With PERCENTAGES2018 as
(select f.acc_account_id,100 - f.cushion as CPPI_PERCENTAGE2018,f.status_investmentplan_datetime from BAM_ACCOUNT_CPPI_CONFIGS b
left join BAM.BAM_RISKINTAKES f on b.acc_account_id = f.acc_account_id
where f.status_investmentplan_datetime = (select max(t1.status_investmentplan_datetime) from BAM.BAM_RISKINTAKES t1 where f.acc_account_id = t1.acc_account_id
and trunc(t1.status_investmentplan_datetime) < to_date('2019-01-01','yyyy-MM-dd') and t1.status_investmentplan in  (2,3))
),

PERCENTAGES2019 as
(
select f.acc_account_id,f.status_investmentplan_datetime , 100 - f.cushion as CPPI_PERCENTAGE2019 from BAM_ACCOUNT_CPPI_CONFIGS b
left join BAM.BAM_RISKINTAKES f on b.acc_account_id = f.acc_account_id
where f.status_investmentplan in  (2,3) and trunc(f.status_investmentplan_datetime) >= to_date('2019-01-01','yyyy-MM-dd') and trunc(f.status_investmentplan_datetime) < to_date('2020-01-01','yyyy-MM-dd')
)

select P2018.* from PERCENTAGES2018 P2018
where P2018.acc_account_id not in (
select P2019.acc_account_id  from PERCENTAGES2019 P2019 where (P2019.CPPI_PERCENTAGE2019 <> P2018.CPPI_PERCENTAGE2018) and P2018.acc_account_id = P2019.acc_account_id);
```
